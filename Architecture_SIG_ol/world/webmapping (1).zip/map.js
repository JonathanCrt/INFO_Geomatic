
var map = new ol.Map({
  target: 'map',
  layers: [
    new ol.layer.Tile({
      source: new ol.source.OSM(),
      opacity: 1
    }),
  ],
  view: new ol.View({
    center: ol.proj.fromLonLat([2, 48]),
    zoom: 6,
    maxZoom: 20,
  })
});
